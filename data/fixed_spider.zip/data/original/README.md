This directory contains the original files from other authors.
These were converted to the data in the directory above through a combination of automatic processing and manual editing.

For some datasets we have also included notes about the process we went through for the conversion.
We also provide some examples of issues we identified, but were unable to resolve.
